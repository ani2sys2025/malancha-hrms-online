
# Malancha OrangeHRM - Render Deployment

Includes:
- Full OrangeHRM structure
- Admin: aniruddha@malancha.co.in / admin123
- MySQL `.env` pre-configured
- Dockerfile + render.yaml
