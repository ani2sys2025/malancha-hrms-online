<?php
$admin_email = 'aniruddha@malancha.co.in';
?>